import argparse
from src.pipeline import run_pipeline

def main():
    parser = argparse.ArgumentParser(description="Honeywell Hackathon — Anomaly Detection V2")
    parser.add_argument(
        "--input_csv",
        default="data/81ce1f00-c3f4-4baa-9b57-006fad1875adTEP_Train_Test.csv",
        help="Path to input dataset CSV"
    )
    parser.add_argument(
        "--config",
        default="config.yaml",
        help="Path to config file"
    )
    parser.add_argument(
        "--output_csv",
        default=None,   # <-- Let pipeline decide model-specific folder
        help="Optional override for output CSV"
    )
    args = parser.parse_args()

    # Run pipeline (pipeline will save under outputs/<model_name>/)
    path = run_pipeline(args.config, args.input_csv, args.output_csv)
    print(f"✅ Saved results to: {path}")


if __name__ == "__main__":
    main()
