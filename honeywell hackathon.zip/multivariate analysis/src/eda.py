import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

def _save(fig_path, use_tight=True):
    Path(fig_path).parent.mkdir(parents=True, exist_ok=True)
    fig = plt.gcf()
    if use_tight:
        try:
            fig.tight_layout()
        except Exception as e:
            print(f"[Warning] Skipping tight_layout for {fig_path}: {e}")
    plt.savefig(fig_path, bbox_inches="tight")
    plt.close()

def summary_and_plots(df: pd.DataFrame, outdir: str):
    Path(outdir).mkdir(parents=True, exist_ok=True)
    df.describe().T.to_csv(Path(outdir)/"summary_stats.csv")

    # Time series and histogram for first 6 numeric columns
    num_cols = df.select_dtypes(include="number").columns[:6]
    for c in num_cols:
        plt.figure()
        df[c].plot(title=f"{c} over time")
        plt.xlabel("Time"); plt.ylabel(c)
        _save(Path(outdir)/"figures"/f"EDA_time_{c}.png")

        plt.figure()
        df[c].hist(bins=50)
        plt.title(f"Histogram: {c}")
        plt.xlabel(c); plt.ylabel("Count")
        _save(Path(outdir)/"figures"/f"EDA_hist_{c}.png")

    # Correlation heatmap (skip tight_layout to avoid warning)
    plt.figure(figsize=(8,6))
    corr = df.corr(numeric_only=True)
    plt.matshow(corr, fignum=1)
    plt.title("Correlation Heatmap", y=1.15)
    plt.xticks(range(len(corr.columns)), corr.columns, rotation=90, fontsize=6)
    plt.yticks(range(len(corr.columns)), corr.columns, fontsize=6)
    _save(Path(outdir)/"figures"/"EDA_corr_heatmap.png", use_tight=False)
