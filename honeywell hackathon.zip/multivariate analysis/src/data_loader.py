
import pandas as pd
import numpy as np
from typing import Tuple, Optional

def load_dataframe(path: str, time_col: str, time_fmt: str) -> pd.DataFrame:
    df = pd.read_csv('data\81ce1f00-c3f4-4baa-9b57-006fad1875adTEP_Train_Test.csv')
    if time_col not in df.columns:
        raise ValueError(f"Time column '{time_col}' not found in {df.columns.tolist()}")
    df[time_col] = pd.to_datetime(df[time_col], format=time_fmt)
    df = df.set_index(time_col).sort_index()
    return df

def infer_or_resample(df: pd.DataFrame, expected_freq: Optional[str] = None) -> pd.DataFrame:
    if expected_freq:
        return df.asfreq(expected_freq)
    diffs = df.index.to_series().diff().dropna()
    if len(diffs) == 0:
        return df
    mode_delta = diffs.mode().iloc[0]
    try:
        # convert mode delta to pandas offset string if possible
        freq = pd.tseries.frequencies.to_offset(mode_delta).freqstr
        return df.asfreq(freq)
    except Exception:
        return df

def split_train(df: pd.DataFrame, start: str, end: str) -> Tuple[pd.DataFrame, pd.DataFrame]:
    train = df.loc[start:end]
    return train, df
