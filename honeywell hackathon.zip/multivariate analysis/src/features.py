
import pandas as pd

def engineer_features(num_df: pd.DataFrame, rolling_windows=(5,15,60), lags=(1,5,15)) -> pd.DataFrame:
    feats = [num_df]
    for w in rolling_windows:
        feats.append(num_df.rolling(window=w, min_periods=1).mean().add_suffix(f"_rollmean_{w}"))
        feats.append(num_df.rolling(window=w, min_periods=1).std().add_suffix(f"_rollstd_{w}"))
    for l in lags:
        feats.append(num_df.shift(l).add_suffix(f"_lag_{l}"))
    out = pd.concat(feats, axis=1)
    return out
