
from pathlib import Path
import pandas as pd

def save_output_csv(out_df: pd.DataFrame, path: str):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    out_df.to_csv(path, index=False)
