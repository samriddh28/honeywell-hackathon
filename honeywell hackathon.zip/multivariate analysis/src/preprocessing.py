
import pandas as pd
import numpy as np

def select_numeric(df: pd.DataFrame) -> pd.DataFrame:
    return df.select_dtypes(include=[np.number])

def impute_linear(df: pd.DataFrame) -> pd.DataFrame:
    return df.interpolate(method="linear", limit_direction="both")

def winsorize(df: pd.DataFrame, lower_q=0.005, upper_q=0.995) -> pd.DataFrame:
    lo = df.quantile(lower_q)
    hi = df.quantile(upper_q)
    return df.clip(lower=lo, upper=hi, axis=1)

def drop_constant(df: pd.DataFrame, thresh: float = 1e-12):
    keep = df.columns[df.std() > thresh]
    return df[keep], [c for c in df.columns if c not in keep]

def standardize(train: pd.DataFrame, full: pd.DataFrame):
    mu = train.mean()
    sd = train.std().replace(0, np.nan)
    tr = (train - mu) / sd
    fl = (full - mu) / sd
    return tr.fillna(0), fl.fillna(0), mu, sd
