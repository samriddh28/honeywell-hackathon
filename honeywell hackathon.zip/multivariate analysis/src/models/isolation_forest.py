
import numpy as np
from sklearn.ensemble import IsolationForest

class IsolationForestModel:
    def __init__(self, **params):
        self.model = IsolationForest(**{k:v for k,v in params.items() if v is not None}, random_state=42)
    def fit(self, X):
        self.model.fit(X)
    def score(self, X):
        return -self.model.decision_function(X).astype(float)
