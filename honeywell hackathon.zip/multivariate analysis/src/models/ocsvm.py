
import numpy as np
from sklearn.svm import OneClassSVM

class OneClassSVMModel:
    def __init__(self, kernel="rbf", nu=0.01, gamma="scale"):
        self.model = OneClassSVM(kernel=kernel, nu=nu, gamma=gamma)
    def fit(self, X): self.model.fit(X)
    def score(self, X): return -self.model.decision_function(X).astype(float)
