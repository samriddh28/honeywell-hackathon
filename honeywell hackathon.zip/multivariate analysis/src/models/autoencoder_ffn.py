
import numpy as np
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Dense
from tensorflow.keras.optimizers import Adam
from sklearn.preprocessing import StandardScaler

class AutoencoderFFN:
    def __init__(self, layers=(128,64,32), bottleneck=16, lr=1e-3, epochs=30, batch_size=128, validation_split=0.1):
        self.layers = layers; self.bottleneck = bottleneck
        self.lr = lr; self.epochs = epochs; self.batch_size = batch_size
        self.validation_split = validation_split
        self.model=None; self.scaler=StandardScaler()
    def _build(self, d):
        x=Input(shape=(d,)); z=x
        for u in self.layers: z=Dense(u, activation="relu")(z)
        z=Dense(self.bottleneck, activation="relu")(z)
        for u in reversed(self.layers): z=Dense(u, activation="relu")(z)
        y=Dense(d, activation="linear")(z)
        m=Model(x,y); m.compile(optimizer=Adam(self.lr), loss="mse"); return m
    def fit(self, X):
        Xs=self.scaler.fit_transform(X); self.model=self._build(Xs.shape[1])
        self.model.fit(Xs, Xs, epochs=self.epochs, batch_size=self.batch_size, shuffle=True,
                       validation_split=self.validation_split, verbose=0)
    def score(self, X):
        Xs=self.scaler.transform(X); R=self.model.predict(Xs, verbose=0)
        return np.mean((Xs-R)**2, axis=1)
    def feature_errors(self, X):
        Xs=self.scaler.transform(X); R=self.model.predict(Xs, verbose=0)
        return (Xs-R)**2
