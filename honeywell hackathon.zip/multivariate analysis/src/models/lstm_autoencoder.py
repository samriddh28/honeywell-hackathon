
import numpy as np
import pandas as pd
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, LSTM, RepeatVector, TimeDistributed, Dense
from tensorflow.keras.optimizers import Adam
from sklearn.preprocessing import StandardScaler

class LSTMAutoencoder:
    def __init__(self, window=30, lstm_units=(64,32), lr=1e-3, epochs=20, batch_size=128, validation_split=0.1):
        self.window=window; self.lstm_units=lstm_units; self.lr=lr
        self.epochs=epochs; self.batch_size=batch_size; self.validation_split=validation_split
        self.scaler=StandardScaler(); self.model=None
    def _build(self, f):
        inp=Input(shape=(self.window, f)); x=inp
        for u in self.lstm_units: x=LSTM(u, activation="tanh", return_sequences=True)(x)
        x=LSTM(self.lstm_units[-1], activation="tanh", return_sequences=False)(x)
        x=RepeatVector(self.window)(x)
        for u in reversed(self.lstm_units): x=LSTM(u, activation="tanh", return_sequences=True)(x)
        out=TimeDistributed(Dense(f))(x)
        m=Model(inp,out); m.compile(optimizer=Adam(self.lr), loss="mse"); return m
    def _windowize(self, X):
        T=len(X); L=self.window
        if T<L: raise ValueError(f"Need at least {L} rows for LSTM windowing")
        return np.stack([X[i-L:i] for i in range(L, T+1)], axis=0)
    def fit(self, X_df: pd.DataFrame):
        X=self.scaler.fit_transform(X_df.values); f=X.shape[1]
        self.model=self._build(f)
        Xw=self._windowize(X)
        self.model.fit(Xw, Xw, epochs=self.epochs, batch_size=self.batch_size, shuffle=True,
                       validation_split=self.validation_split, verbose=0)
    def score(self, X_df: pd.DataFrame):
        X=self.scaler.transform(X_df.values); Xw=self._windowize(X)
        R=self.model.predict(Xw, verbose=0)
        mse=np.mean((Xw-R)**2, axis=(1,2))
        pad=np.full((self.window-1,), mse[0])
        return np.concatenate([pad, mse], axis=0)
    def feature_errors_last(self, X_df: pd.DataFrame):
        X=self.scaler.transform(X_df.values); Xw=self._windowize(X)
        R=self.model.predict(Xw, verbose=0)
        se=(Xw-R)**2
        per_feat=se[:, -1, :]
        pad=np.tile(per_feat[0], (self.window-1,1))
        return np.vstack([pad, per_feat])
