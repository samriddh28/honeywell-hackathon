
import numpy as np
from sklearn.decomposition import PCA

class PCAReconstruction:
    def __init__(self, n_components=0.95):
        self.pca=PCA(n_components=n_components, svd_solver="full"); self.mean_=None
    def fit(self, X):
        self.mean_=X.mean(axis=0)
        self.pca.fit(X - self.mean_)
    def score(self, X):
        Xc=X - self.mean_; Z=self.pca.transform(Xc); Xh=self.pca.inverse_transform(Z)
        return ((Xc-Xh)**2).mean(axis=1)
    def feature_errors(self, X):
        Xc=X - self.mean_; Z=self.pca.transform(Xc); Xh=self.pca.inverse_transform(Z)
        return (Xc-Xh)**2
