
import numpy as np
import pandas as pd
from scipy.stats import rankdata

def to_0_100(scores, method="percentile"):
    s = np.asarray(scores, dtype=float).ravel()
    if len(s)==0: return s
    if method=="percentile":
        return rankdata(s, method="average")/len(s)*100.0
    lo, hi = float(np.min(s)), float(np.max(s))
    if hi-lo < 1e-12: return (s*0)
    return (s-lo)/(hi-lo)*100.0

def z_contrib(train_df: pd.DataFrame, full_df: pd.DataFrame) -> pd.DataFrame:
    mu = train_df.mean()
    sd = train_df.std().replace(0, np.nan)
    zabs = (full_df - mu).abs() / sd
    zabs = zabs.fillna((full_df - mu).abs())
    share = zabs.div(zabs.sum(axis=1).replace(0, np.nan), axis=0)
    return share

def top_k_contributors(contrib_share: pd.DataFrame, k=7, min_share=0.01) -> pd.DataFrame:
    cols=[f"top_feature_{i}" for i in range(1,k+1)]
    top=pd.DataFrame(index=contrib_share.index, columns=cols, dtype=object)
    for idx,row in contrib_share.iterrows():
        s=row[row>min_share].sort_values(ascending=False)
        names=list(s.index[:k]); names += [""]*(k-len(names))
        top.loc[idx,:]=names
    return top
