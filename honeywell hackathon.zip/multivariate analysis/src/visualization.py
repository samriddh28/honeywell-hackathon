
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

def _save(path):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    plt.tight_layout(); plt.savefig(path); plt.close()

def plot_degree_of_anomaly(result_df: pd.DataFrame, outdir: str, names: dict):
    # Timeline
    plt.figure()
    result_df["abnormality_score"].plot(title="Degree of Anomaly vs Time")
    plt.xlabel("Time"); plt.ylabel("Degree of Anomaly (0–100)")
    _save(Path(outdir)/names["timeline"])

    # Histogram
    plt.figure()
    result_df["abnormality_score"].plot(kind="hist", bins=50, title="Degree of Anomaly Distribution")
    plt.xlabel("Degree of Anomaly (0–100)"); plt.ylabel("Count")
    _save(Path(outdir)/names["histogram"])

    # Contributors frequency (Top 20)
    top_cols=[c for c in result_df.columns if c.startswith("top_feature_")]
    vals = result_df[top_cols].values.ravel()
    vals = pd.Series([v for v in vals if isinstance(v,str) and v!=""]).value_counts().head(20)
    plt.figure(figsize=(8,5))
    vals.sort_values(ascending=True).plot(kind="barh", title="Top Feature Contributors")
    plt.xlabel("Count"); plt.ylabel("Feature")
    _save(Path(outdir)/names["contributors"])
