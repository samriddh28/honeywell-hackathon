
import numpy as np
import random
import logging

def set_global_seed(seed: int = 42):
    import tensorflow as tf
    np.random.seed(seed)
    random.seed(seed)
    try:
        tf.random.set_seed(seed)
    except Exception:
        pass

def setup_logging():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(name)s | %(message)s")
    return logging.getLogger("honeywell-v2")

def safe_columns(df):
    return [c for c in df.columns if str(c).strip() != ""]
