import yaml
import pandas as pd
from pathlib import Path

from .utils import set_global_seed, setup_logging
from .data_loader import load_dataframe, infer_or_resample, split_train
from .preprocessing import select_numeric, impute_linear, winsorize, drop_constant, standardize
from .features import engineer_features
from .scoring import to_0_100, z_contrib, top_k_contributors
from .visualization import plot_degree_of_anomaly
from .reporting import save_output_csv

from .models.isolation_forest import IsolationForestModel
from .models.autoencoder_ffn import AutoencoderFFN
from .models.lstm_autoencoder import LSTMAutoencoder
from .models.ocsvm import OneClassSVMModel
from .models.pca_reconstruction import PCAReconstruction


def run_pipeline(cfg_path: str, input_csv: str, output_csv: str = None):
    log = setup_logging()
    with open(cfg_path, "r") as f:
        cfg = yaml.safe_load(f)
    set_global_seed(cfg.get("random_seed", 42))

    # Extract model name from config
    name = cfg["model"]["name"]

    # ---------------- CREATE MODEL-SPECIFIC DIRS ----------------
    base_out_dir = Path(cfg["output"]["dir"]) / name
    eda_outdir = Path(cfg["eda"]["outdir"]) / name
    viz_outdir = Path(cfg["visualization"]["outdir"]) / name
    base_out_dir.mkdir(parents=True, exist_ok=True)
    eda_outdir.mkdir(parents=True, exist_ok=True)
    viz_outdir.mkdir(parents=True, exist_ok=True)

    # ---------------- LOAD & RESAMPLE ----------------
    df0 = load_dataframe(input_csv, cfg["time"]["column"], cfg["time"]["format"])
    df0 = infer_or_resample(df0, cfg["time"].get("expected_freq"))

    # ---------------- EDA ----------------
    if cfg.get("eda", {}).get("enable", True):
        from .eda import summary_and_plots
        summary_and_plots(df0, str(eda_outdir))

    # ---------------- PREPROCESS ----------------
    Xn = select_numeric(df0)
    Xn = impute_linear(Xn)
    Xn = winsorize(Xn, cfg["preprocessing"]["winsorize_lower_q"], cfg["preprocessing"]["winsorize_upper_q"])
    Xn, dropped = drop_constant(Xn)
    if dropped:
        log.info(f"Dropped constant features: {dropped}")

    # ---------------- FEATURE ENGINEERING ----------------
    if cfg["features"]["enable_engineering"]:
        Xf = engineer_features(Xn, cfg["features"]["rolling_windows"], cfg["features"]["include_lags"])
        if cfg["features"]["drop_na_after_engineering"]:
            Xf = Xf.dropna()
            df0 = df0.loc[Xf.index]
    else:
        Xf = Xn

    # ---------------- SPLIT + STANDARDIZE ----------------
    train_df, full_df = split_train(Xf, cfg["time"]["train_start"], cfg["time"]["train_end"])
    Xtr_s, Xfl_s, mu, sd = standardize(train_df, full_df)

    # ---------------- MODEL SELECTION ----------------
    try:
        if name == "isolation_forest":
            m = IsolationForestModel(**cfg["isolation_forest"])
            m.fit(Xtr_s)
            raw = m.score(Xfl_s)
            contrib = z_contrib(pd.DataFrame(Xtr_s, index=train_df.index, columns=train_df.columns),
                                pd.DataFrame(Xfl_s, index=full_df.index, columns=full_df.columns))
            top = top_k_contributors(contrib, 7, 0.01)

        elif name == "autoencoder_ffn":
            ae = AutoencoderFFN(**cfg["autoencoder_ffn"])
            ae.fit(pd.DataFrame(Xtr_s, index=train_df.index, columns=train_df.columns))
            raw = ae.score(pd.DataFrame(Xfl_s, index=full_df.index, columns=full_df.columns))
            fe = ae.feature_errors(pd.DataFrame(Xfl_s, index=full_df.index, columns=full_df.columns))
            share = fe / (fe.sum(axis=1, keepdims=True) + 1e-12)
            top = top_k_contributors(pd.DataFrame(share, index=full_df.index, columns=full_df.columns), 7, 0.01)

        elif name == "lstm_autoencoder":
            lstm = LSTMAutoencoder(**cfg["lstm_autoencoder"])
            lstm.fit(pd.DataFrame(Xtr_s, index=train_df.index, columns=train_df.columns))
            raw = lstm.score(pd.DataFrame(Xfl_s, index=full_df.index, columns=full_df.columns))
            fe = lstm.feature_errors_last(pd.DataFrame(Xfl_s, index=full_df.index, columns=full_df.columns))
            share = fe / (fe.sum(axis=1, keepdims=True) + 1e-12)
            top = top_k_contributors(pd.DataFrame(share, index=full_df.index, columns=full_df.columns), 7, 0.01)

        elif name == "ocsvm":
            oc = OneClassSVMModel(**cfg["ocsvm"])
            oc.fit(Xtr_s)
            raw = oc.score(Xfl_s)
            contrib = z_contrib(pd.DataFrame(Xtr_s, index=train_df.index, columns=train_df.columns),
                                pd.DataFrame(Xfl_s, index=full_df.index, columns=full_df.columns))
            top = top_k_contributors(contrib, 7, 0.01)

        elif name == "pca_reconstruction":
            pca = PCAReconstruction(**cfg["pca_reconstruction"])
            pca.fit(Xtr_s)
            raw = pca.score(Xfl_s)
            fe = pca.feature_errors(Xfl_s)
            share = fe / (fe.sum(axis=1, keepdims=True) + 1e-12)
            top = top_k_contributors(pd.DataFrame(share, index=full_df.index, columns=full_df.columns), 7, 0.01)

        else:
            raise ValueError(f"Unknown model: {name}")

    except Exception as e:
        log.warning(f"Model '{name}' failed with error {e}. Falling back to IsolationForest.")
        m = IsolationForestModel(**cfg["isolation_forest"])
        m.fit(Xtr_s)
        raw = m.score(Xfl_s)
        contrib = z_contrib(pd.DataFrame(Xtr_s, index=train_df.index, columns=train_df.columns),
                            pd.DataFrame(Xfl_s, index=full_df.index, columns=full_df.columns))
        top = top_k_contributors(contrib, 7, 0.01)

    # ---------------- SCALING ----------------
    abnormality = to_0_100(raw, cfg["scaling"]["method"])

    # ---------------- OUTPUT ----------------
    out = df0.reset_index().copy()
    out["abnormality_score"] = abnormality
    for c in top.columns:
        out[c] = top[c].values

    # Save CSV in model-specific folder
    out_path = base_out_dir / cfg["output"]["filename"]
    if output_csv:
        out_path = Path(output_csv)
    save_output_csv(out, str(out_path))

    # Save anomaly plots in model-specific folder
    plot_degree_of_anomaly(out, str(viz_outdir), cfg["visualization"]["names"])

    return str(out_path)
