# Step Plan (v2) — 2025-08-23T18:56:22.405241
- Visualizations named per brief:
  - reports/figures/Degree_of_Anomaly_vs_Time.png
  - reports/figures/Degree_of_Anomaly_Distribution.png
  - reports/figures/Top_Feature_Contributors.png
- Edge cases handled: resampling, missing/constant cols, zero-std, fallback model.
- See `config.yaml` to switch models and plot names.
