
import pandas as pd
import numpy as np
from src.scoring import to_0_100

def test_scaling_constant_array():
    s = np.ones(10)
    out = to_0_100(s, method="minmax")
    assert (out == 0).all()

def test_top_contributors_shape():
    # Ensure exactly 7 columns created even if few features
    from src.scoring import top_k_contributors
    df = pd.DataFrame({"a":[0.9,0.9], "b":[0.05,0.06], "c":[0.04,0.04]})
    top = top_k_contributors(df, k=7, min_share=0.01)
    assert top.shape[1] == 7
